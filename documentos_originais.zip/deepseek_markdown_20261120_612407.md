# Formalismo comprimido

## 1. Cálculo funcional de Borel

No espaço finito $\mathcal{H} = \mathbb{R}^{8V}$ sejam $M_A$ o operador
de Faddeev–Popov e $\Delta_A$ o laplaciano covariante. Os dois cortes de
regime são medidas espectrais:

$$
P_c = E_{M_A}\bigl([\lambda_c,\infty)\bigr),
\qquad
p_\Lambda = E_{\widehat{H}_\tau}\bigl([0,\Lambda]\bigr).
$$

No limite $T\to 0$, $P_c$ é a projeção espectral do operador integrado

$$
H_T = \int_0^T \Phi_t^*(M_A^{-1})\,dt,
$$

com $\Phi_t$ o fluxo de Wilson. O operador ultravioleta é

$$
\widehat{H}_\tau = -\frac{1}{\tau}\log \overline{K}_\tau,
\qquad
\overline{K}_\tau = \frac{1}{T}\int_0^T e^{-\tau\Delta_{A(t)}}\,dt.
$$

## 2. Ângulos de Friedrichs/Halmos

$$
\Theta = \arccos |P_c p_\Lambda|,
\qquad
\sigma(\Theta)\subset (0,\pi/2).
$$

Pelo teorema de Halmos,

$$
\mathcal{H} =
(P_c\wedge p_\Lambda)
\oplus (P_c\wedge p_\Lambda^\perp)
\oplus (P_c^\perp\wedge p_\Lambda)
\oplus (P_c^\perp\wedge p_\Lambda^\perp)
\oplus \mathcal{H}_g .
$$

No bloco genérico,

$$
P_c \sim \begin{pmatrix}1&0\\0&0\end{pmatrix},
\qquad
p_\Lambda \sim
\begin{pmatrix}
\cos^2\Theta & \cos\Theta\sin\Theta\\
\cos\Theta\sin\Theta & \sin^2\Theta
\end{pmatrix},
$$

portanto

$$
\mathcal{A}(\lambda_c,\Lambda)
= \{P_c,p_\Lambda\}''
\cong
\bigoplus_{\text{4 cantos}}\mathbb{C}
\oplus
\int_{\sigma(\Theta)}^{\oplus} M_2(\mathbb{C})\,d\mu(\Theta),
$$

que é Tipo I e finita. A cota do inverso comprimido é

$$
p_\Lambda M_A^+ p_\Lambda
\ge \lambda_1^{-1} p_\Lambda |v_1\rangle\langle v_1| p_\Lambda,
\qquad
f_1 \le \lambda_1 \|p_\Lambda M_A^+ p_\Lambda\| \le 1.
$$

## 3. Funtor de escala e torre de Jones

$$
\mathcal{F}_{\mathrm{reg}} :
\mathbf{Lat} \to \mathbf{vNAlg}_{\mathrm{fin}}^\tau,
\qquad
\mathcal{F}_{\mathrm{reg}}(L,\beta,\lambda_c,\Lambda)
= \mathcal{A}_{L,\beta}(\lambda_c,\Lambda).
$$

A torre é um sistema indutivo com inclusões que preservam traço:

$$
\mathcal{A}_{L_1} \hookrightarrow \mathcal{A}_{L_2} \hookrightarrow \cdots,
\qquad
\tau_{k+1}\circ\iota_k = \tau_k.
$$

Sob hipótese,

$$
\mathcal{R}_{\mathrm{II}_1}
= \overline{\varinjlim_k (\mathcal{A}_{L_k},\tau_k)}^{\,w^*},
\qquad
\mathcal{N}_{\mathrm{II}_\infty}
= \mathcal{R}_{\mathrm{II}_1}\rtimes_\sigma \mathbb{R}.
$$

Em dimensão finita o fluxo modular é interno; o produto cruzado por fluxo
interno é Tipo I com centro. O salto para II$_1$/II$_\infty$/III$_1$ é
hipótese do contínuo.

## 4. Osterwalder–Schrader

OS0–OS4 dão a reconstrução $(\mathcal{H}_{\mathrm{OS}},\Omega)$ e o fluxo
modular de Tomita–Takesaki. O tipo III$_1$ do contínuo é uma hipótese
$H_{\mathrm{Connes}}$ adicional, não um teorema da rede finita.