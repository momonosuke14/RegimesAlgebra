"""Spectral definitions of the two regime operators."""
from __future__ import annotations

import numpy as np
from scipy.linalg import expm


def spectral_projector(A: np.ndarray, mask) -> np.ndarray:
    """Return E_A(mask), the orthogonal spectral projector of A."""
    w, V = np.linalg.eigh(A)
    cols = V[:, np.array([mask(x) for x in w], dtype=bool)]
    return cols @ cols.conj().T


def logm_herm(A: np.ndarray, eps: float = 1e-300) -> np.ndarray:
    """Hermitian matrix logarithm via eigendecomposition."""
    w, V = np.linalg.eigh(A)
    w = np.clip(w, eps, None)
    return (V * np.log(w)) @ V.conj().T


def integrated_inverse(Ms, weights) -> np.ndarray:
    """H_T = sum_i w_i M_i^{-1}; trapezoid weights sum to T."""
    total = 0.0
    for w, M in zip(weights, Ms):
        total = total + w * np.linalg.inv(M)
    return total


def uv_operator_from_deltas(Ds, weights, tau: float) -> np.ndarray:
    """Hhat_tau = -(1/tau) log( sum_i w_i exp(-tau Delta_i) ), sum w_i = 1."""
    Kbar = 0.0
    for w, D in zip(weights, Ds):
        Kbar = Kbar + w * expm(-tau * np.asarray(D))
    return -logm_herm(Kbar) / tau