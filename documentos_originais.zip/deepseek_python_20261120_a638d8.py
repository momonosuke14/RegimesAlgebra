"""Algebra of regimes — helper package."""
from .operators import (
    spectral_projector,
    integrated_inverse,
    uv_operator_from_deltas,
    logm_herm,
)
from .angles import (
    intersection_dim,
    friedrichs_angles,
    commutator_norm_generic,
    compressed_inverse_bound,
)
from .kpm import heat_kernel_moments

__version__ = "0.1.0"

__all__ = [
    "spectral_projector",
    "integrated_inverse",
    "uv_operator_from_deltas",
    "logm_herm",
    "intersection_dim",
    "friedrichs_angles",
    "commutator_norm_generic",
    "compressed_inverse_bound",
    "heat_kernel_moments",
]