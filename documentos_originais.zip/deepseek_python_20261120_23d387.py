"""Generate the three figures used in the compressed paper."""
from __future__ import annotations

import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

os.makedirs("figures", exist_ok=True)


def figure_friedrichs_angle():
    th = np.linspace(0.0, np.pi / 2, 400)
    fig, ax = plt.subplots(figsize=(4, 4))
    ax.plot(np.cos(th), np.sin(th), lw=1.5)
    ax.axhline(0, color="gray", lw=0.5)
    ax.axvline(0, color="gray", lw=0.5)
    ax.set_aspect("equal")
    ax.set_xlim(-0.05, 1.05)
    ax.set_ylim(-0.05, 1.05)
    ax.set_xlabel(r"$\cos\Theta$")
    ax.set_ylabel(r"$\sin\Theta$")
    ax.set_title(r"Friedrichs angle for $(P_c,p_\Lambda)$")
    fig.tight_layout()
    fig.savefig("figures/friedrichs_angle.pdf")
    fig.savefig("figures/friedrichs_angle.png", dpi=160)
    plt.close(fig)


def figure_halmos_corners():
    fig, ax = plt.subplots(figsize=(5, 3.2))
    corners = [
        (0.1, 0.7, r"$P_c\wedge p_\Lambda$"),
        (0.6, 0.7, r"$P_c\wedge p_\Lambda^\perp$"),
        (0.1, 0.15, r"$P_c^\perp\wedge p_\Lambda$"),
        (0.6, 0.15, r"$P_c^\perp\wedge p_\Lambda^\perp$"),
    ]
    for x, y, lab in corners:
        ax.add_patch(plt.Rectangle((x, y), 0.3, 0.15, fill=True, alpha=0.3))
        ax.text(x + 0.15, y + 0.075, lab, ha="center", va="center", fontsize=9)
    ax.text(0.5, -0.08,
            r"$+\ \mathcal{H}_g$ (generic block, $M_2(\mathbb{C})$ pointwise)",
            ha="center", fontsize=9)
    ax.set_xlim(0, 1)
    ax.set_ylim(-0.15, 1)
    ax.axis("off")
    ax.set_title("Halmos decomposition of $(P_c, p_\\Lambda)$", fontsize=10)
    fig.tight_layout()
    fig.savefig("figures/halmos_corners.pdf")
    fig.savefig("figures/halmos_corners.png", dpi=160)
    plt.close(fig)


def figure_tower():
    fig, ax = plt.subplots(figsize=(8, 2.2))
    labels = [
        r"$\mathcal{A}_{L_1}$",
        r"$\mathcal{A}_{L_2}$",
        r"$\cdots$",
        r"$\mathcal{R}_{\mathrm{II}_1}$",
        r"$\mathcal{N}_{\mathrm{II}_\infty}$",
    ]
    x = np.arange(len(labels))
    ax.plot(x, np.zeros_like(x), "o-", lw=1)
    for xi, lab in zip(x, labels):
        ax.text(xi, 0.10, lab, ha="center")
    ax.text(len(labels) - 1, -0.20,
            r"continuum limit: OS + $H_{\mathrm{Connes}}$ (conditional)",
            ha="center", fontsize=8, style="italic")
    ax.set_xlim(-0.5, len(labels) - 0.5)
    ax.set_ylim(-0.3, 0.3)
    ax.axis("off")
    ax.set_title(
        r"Scale functor and Jones tower (Type I → II$_1$ → II$_\infty$/III$_1$)",
        fontsize=10)
    fig.tight_layout()
    fig.savefig("figures/tower.pdf")
    fig.savefig("figures/tower.png", dpi=160)
    plt.close(fig)


if __name__ == "__main__":
    figure_friedrichs_angle()
    figure_halmos_corners()
    figure_tower()
    print("Figures written to figures/")