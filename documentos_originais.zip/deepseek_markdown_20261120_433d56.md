# Data

Os dados brutos do ColorLattice (ensembles em 4^4 com nove acoplamentos e o
teste matrix-free em 6^4) ficam fora deste repositório por tamanho. Para
reproduzir, use o pipeline ColorLattice e salve como `.npz`:
