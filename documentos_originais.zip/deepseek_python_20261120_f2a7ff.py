"""Friedrichs/Halmos angle tools for a pair of orthogonal projections."""
from __future__ import annotations

import numpy as np
from scipy.linalg import null_space


def intersection_dim(P: np.ndarray, p: np.ndarray, tol: float = 1e-9) -> int:
    """dim( ran P ∩ ran p ) for orthogonal projections P and p."""
    I = np.eye(P.shape[0])
    N = null_space(np.vstack([I - P, I - p]), rcond=tol)
    return int(N.shape[1])


def friedrichs_angles(P: np.ndarray, p: np.ndarray,
                      tol: float = 1e-10) -> np.ndarray:
    """Generic Friedrichs angles theta in (0, pi/2)."""
    s = np.linalg.svd(P @ p, compute_uv=False)
    s = np.clip(s, 0.0, 1.0)
    th = np.arccos(s)
    return th[(th > tol) & (th < np.pi / 2 - tol)]


def commutator_norm_generic(P: np.ndarray, p: np.ndarray) -> float:
    """|| [P, p] || on the generic block = max 0.5 |sin 2 Theta|."""
    th = friedrichs_angles(P, p)
    if th.size == 0:
        return 0.0
    return float(np.max(0.5 * np.abs(np.sin(2.0 * th))))


def compressed_inverse_bound(M: np.ndarray, p: np.ndarray,
                             v1: np.ndarray, lam1: float
                             ) -> tuple[float, float]:
    """Return (f1, lambda1 * || p M^+ p ||) for the Conjecture-1 bound."""
    Mplus = np.linalg.pinv(M, hermitian=True)
    B = p @ Mplus @ p
    f1 = float(np.linalg.norm(p @ v1) ** 2)
    return f1, float(lam1 * np.linalg.norm(B, 2))