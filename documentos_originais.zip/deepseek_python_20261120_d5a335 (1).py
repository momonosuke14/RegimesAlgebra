"""Chebyshev expansion of the heat kernel on spec(A) ⊂ [0, 8]."""
from __future__ import annotations

import numpy as np
from scipy.special import iv


def heat_kernel_chebyshev(A: np.ndarray, tau: float, K: int = 18) -> np.ndarray:
    """exp(-tau A) via Chebyshev, using a = 4*tau, x = (A - 4)/4."""
    a = 4.0 * tau
    n = A.shape[0]
    x = (A - 4.0 * np.eye(n)) / 4.0
    prev2 = np.eye(n)              # T_0
    prev1 = x                      # T_1
    acc = iv(0, a) * prev2
    if K >= 1:
        acc = acc + 2.0 * (-1) ** 1 * iv(1, a) * prev1
    for k in range(2, K + 1):
        Tk = 2.0 * x @ prev1 - prev2
        acc = acc + 2.0 * (-1) ** k * iv(k, a) * Tk
        prev2, prev1 = prev1, Tk
    return np.exp(-a) * acc


def heat_kernel_moments(A: np.ndarray, tau: float, K: int = 18
                        ) -> np.ndarray:
    """mu_k = Tr T_k(2*Kbar - 1) / dim, for Kbar = exp(-tau A) normalized."""
    Kbar = heat_kernel_chebyshev(A, tau, K)
    n = Kbar.shape[0]
    x = 2.0 * Kbar - np.eye(n)
    mu = np.zeros(K + 1)
    prev2 = np.eye(n)
    prev1 = x
    mu[0] = np.trace(prev2) / n
    if K >= 1:
        mu[1] = np.trace(prev1) / n
    for k in range(2, K + 1):
        Tk = 2.0 * x @ prev1 - prev2
        mu[k] = np.trace(Tk) / n
        prev2, prev1 = prev1, Tk
    return mu