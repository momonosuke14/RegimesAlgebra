"""Structural smoke tests for the algebra-of-regimes package."""
from __future__ import annotations

import sys
import numpy as np

sys.path.insert(0, "src")
from regimes import (  # noqa: E402
    spectral_projector,
    intersection_dim,
    friedrichs_angles,
    commutator_norm_generic,
    compressed_inverse_bound,
    uv_operator_from_deltas,
)

RESULTS = []


def check(name, cond):
    RESULTS.append((name, bool(cond)))
    print(f"[{'PASS' if cond else 'FAIL'}] {name}")


def main():
    rng = np.random.default_rng(0)

    A = np.diag([1.0, 2.0, 3.0, 4.0])
    P = spectral_projector(A, lambda x: x <= 2.0)
    check("spectral_projector rank", int(np.round(np.trace(P))) == 2)
    check("spectral_projector idempotent", np.allclose(P @ P, P))

    I = np.eye(4)
    Z = np.zeros((4, 4))
    check("dim(I ∩ 0) = 0", intersection_dim(I, Z) == 0)
    check("dim(I ∩ I) = 4", intersection_dim(I, I) == 4)
    E1 = spectral_projector(np.diag([1, 2, 3, 4]), lambda x: x <= 2)
    E2 = spectral_projector(np.diag([1, 2, 3, 4]), lambda x: x <= 3)
    check("dim(E1 ∩ E2) = 2", intersection_dim(E1, E2) == 2)

    n = 20
    Q1, _ = np.linalg.qr(rng.standard_normal((n, n)))
    Q2, _ = np.linalg.qr(rng.standard_normal((n, n)))
    P = Q1[:, : n // 2] @ Q1[:, : n // 2].T
    p = Q2[:, : n // 2] @ Q2[:, : n // 2].T
    th = friedrichs_angles(P, p)
    check("Friedrichs angles in (0, pi/2)",
          th.size == 0 or ((th > 0).all() and (th < np.pi / 2).all()))
    cn = commutator_norm_generic(P, p)
    check("commutator norm ≤ 1/2", cn <= 0.5 + 1e-12)

    M = np.diag([0.01, 1.0, 2.0, 3.0])
    v1 = np.array([1.0, 0.0, 0.0, 0.0])
    p = np.eye(4)
    lam1 = 0.01
    f1, rhs = compressed_inverse_bound(M, p, v1, lam1)
    check("f1 ≤ λ1 ||p M^+ p||", f1 <= rhs + 1e-12)
    check("λ1 ||p M^+ p|| ≤ 1", rhs <= 1.0 + 1e-12)

    Ds = [np.diag([0.0, 1.0, 2.0]), np.diag([0.0, 1.0, 2.0])]
    Hhat = uv_operator_from_deltas(Ds, [0.5, 0.5], tau=0.5)
    check("UV operator reproduces Delta_0 on a constant flow",
          np.allclose(Hhat, Ds[0], atol=1e-10))

    n_fail = sum(1 for _, ok in RESULTS if not ok)
    print(f"\n{len(RESULTS) - n_fail}/{len(RESULTS)} checks passed.")
    return 0 if n_fail == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())